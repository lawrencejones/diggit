require_relative './person.rb'

class Adult < Person
  def say_name
    puts(@name.upcase)
  end
end
